from flask import *
import os


UPLOAD_FOLDER = '../static'
ALLOWED_EXTENSIONS = set(['png', 'jpg', 'jpeg', 'gif'])

app = Flask(__name__,template_folder="templates")


@app.route('/', methods = ['POST', 'GET'])
def main():
    error = None
    if request.method == 'POST':
        if request.form['album'] not in ['Layla','Trains']:
            error = 'Sorry, we do not have that album right now'


        else:
            if request.form['album'] == 'Trains':
                result = "https://www.youtube.com/watch?v=0UHwkfhwjsk"
            elif request.form['album'] == 'Layla':
                    result = "https://www.youtube.com/watch?v=fX5USg8_1gA"

            return render_template('album.html',result=result)

    return render_template('index.html',error=error)

if __name__=='__main__':
    app.run(debug=True)